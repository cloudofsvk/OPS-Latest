========
Usage
========

To use nova-docker in a project::

	import novadocker